# Unity Test - Known Issues

## A Note

This project will do its best to keep track of significant bugs that might effect your usage of this
project and its supporting scripts. A more detailed and up-to-date list for cutting edge Unity can
be found on our Github repository.

## Issues

  - No built-in validation of no-return functions
  - Incomplete support for Printf-style formatting
  - Incomplete support for VarArgs
